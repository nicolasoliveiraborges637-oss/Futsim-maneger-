FUTSIM MANAGER — PROJETO ANDROID

Este é o projeto-fonte Android (WebView) que empacota o protótipo web incluído em app/src/main/assets/site.

COMO GERAR O APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta FUTSIM_Manager_AndroidStudio no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK Platform 35 quando solicitado.
4. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste será criado em app/build/outputs/apk/debug/app-debug.apk.
6. Copie o APK para o Android e autorize a instalação de apps dessa origem, se solicitado.

OBSERVAÇÕES:
- Este pacote é o projeto-fonte para compilação, não um APK já compilado.
- O app abre o jogo localmente dentro de uma WebView e mantém os arquivos no próprio aplicativo.
- Recursos online/multiplayer real exigem backend e conexão; não são habilitados por este empacotamento.
